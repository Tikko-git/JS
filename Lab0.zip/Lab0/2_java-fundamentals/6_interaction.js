let userName = prompt('What is your name?', '');

let isCorrectName = confirm(`Is your name ${userName}?`);

alert(isCorrectName);

let admin;
let userName = 'John';

admin = userName;

alert(admin);


let planetName = 'Earth';
let currentUserName = 'Alexandra';

const BIRTHDAY = '03.02.2005';
const age = someCode(BIRTHDAY);
